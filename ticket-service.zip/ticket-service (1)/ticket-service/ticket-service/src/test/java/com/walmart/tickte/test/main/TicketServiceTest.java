package com.walmart.tickte.test.main;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.walmart.tickte.test.ticketService.FindAndHoldSeatsTest;
import com.walmart.tickte.test.ticketService.FindNumberOFSeatsTest;
import com.walmart.tickte.test.ticketService.ReseveSeatsTest;

@RunWith(Suite.class)
@SuiteClasses({FindNumberOFSeatsTest.class, FindAndHoldSeatsTest.class, ReseveSeatsTest.class})
public class TicketServiceTest {

}
