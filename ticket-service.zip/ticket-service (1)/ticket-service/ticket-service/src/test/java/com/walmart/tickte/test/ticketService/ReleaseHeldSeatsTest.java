package com.walmart.tickte.test.ticketService;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.walmart.ticket.service.constants.SeatLevel;
import com.walmart.ticket.service.constants.SeatStatusEnum;
import com.walmart.ticket.service.impl.TicketServiceImpl;
import com.walmart.ticket.service.impl.TicketServiceInit;
import com.walmart.ticket.service.model.SeatHold;

public class ReleaseHeldSeatsTest {
	
	TicketServiceImpl impl=null;
	TicketServiceInit init=null;
	
	@Before
	public void init(){
		 init = new TicketServiceInit(10);
		 impl = new TicketServiceImpl();
	}


	/**
	 * Test method for {@link com.walmart.ticket.service.impl.TicketServiceImpl#releaseHeldTickets(int, java.lang.String)}.
	 */
	@Test
	public void testReleaseHeldTickets() {
		 init = new TicketServiceInit(10);
		impl.setRequiredLevel(SeatLevel.BALCONY.getLevel());
		SeatHold hold =impl.findAndHoldSeats(2, "abc@hai.com") ;
		Double amoun = 50d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 2);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 88);
		
		impl.releaseHeldTickets(hold.getSeatHoldId());
		
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 0);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 90);
		
		
	}


}
