/**
 * 
 */
package com.walmart.tickte.test.ticketService;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.sun.tracing.dtrace.FunctionName;
import com.walmart.ticket.service.constants.SeatLevel;
import com.walmart.ticket.service.constants.SeatStatusEnum;
import com.walmart.ticket.service.impl.TicketServiceImpl;
import com.walmart.ticket.service.impl.TicketServiceInit;
import com.walmart.ticket.service.model.SeatHold;

/**
 * @author mandar puranik
 *
 */
public class FindNumberOFSeatsTest {

	/**
	 * Test method for {@link com.walmart.ticket.service.impl.TicketServiceImpl#numSeatsAvailable()}.
	 */
	
	TicketServiceImpl impl=null;
	TicketServiceInit init=null;
	
	@Before
	public void init(){
		 init = new TicketServiceInit(10);
		 impl = new TicketServiceImpl();
	}
	
	
	
	@Test
	public void testTotalNumSeatsAvailable() {
		System.out.println();
		 assertEquals(impl.numSeatsAvailable(), 90);
	}

	
	@Test
	public void testMezza9NumSeatsAvailable() {
		impl.setRequiredLevel(SeatLevel.MEZZANINE.getLevel());
		 assertEquals(impl.numSeatsAvailable(), 30);
	}
	/**
	 * Test method for {@link com.walmart.ticket.service.impl.TicketServiceImpl#findAndHoldSeats(int, java.lang.String)}.
	 */
	@Test
	public void testNegFindAndHoldSeats() {
		
		impl.setRequiredLevel(SeatLevel.ORCHESTRA.getLevel());
		assertEquals(impl.findAndHoldSeats(40, "abc@hai.com") , null);
		
	}
	
	



}
