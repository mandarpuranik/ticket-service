package com.walmart.tickte.test.ticketService;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.walmart.ticket.service.constants.SeatLevel;
import com.walmart.ticket.service.constants.SeatStatusEnum;
import com.walmart.ticket.service.impl.TicketServiceImpl;
import com.walmart.ticket.service.impl.TicketServiceInit;
import com.walmart.ticket.service.model.SeatHold;

public class ReseveSeatsTest {
	
	TicketServiceImpl impl=null;
	TicketServiceInit init=null;
	
	@Before
	public void init(){
		 init = new TicketServiceInit(10);
		 impl = new TicketServiceImpl();
	}
	

	/**
	 * Test method for {@link com.walmart.ticket.service.impl.TicketServiceImpl#reserveSeats(int, java.lang.String)}.
	 */
	@Test
	public void testReserveSeatsAtBalcony() {
		init = new TicketServiceInit(10);
		
		impl.setRequiredLevel(SeatLevel.BALCONY.getLevel());
		SeatHold hold =impl.findAndHoldSeats(2, "abc@hai.com") ;
		Double amoun = 50d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		
		String res = impl.reserveSeats(hold.getSeatHoldId(), "abcwrong@hai.com");
		//assertEquals(res.startsWith("C"), false);
		assertEquals(hold.isReserved(), false);

		
		res = impl.reserveSeats(hold.getSeatHoldId(), "abc@hai.com");
		//assertEquals(res.startsWith("C"), true);
		assertEquals(hold.isReserved(), true);
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 0);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 88);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.RESERVED.getStatus())).size() , 2);
		
	}

	@Test
	public void testReserveSeatsAtOrchestra() {
		
		init = new TicketServiceInit(10);
		
		impl.setRequiredLevel(SeatLevel.ORCHESTRA.getLevel());
		SeatHold hold =impl.findAndHoldSeats(2, "abc@hai.com") ;
		Double amoun = 200d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		
		String res = impl.reserveSeats(hold.getSeatHoldId(), "abcwrong@hai.com");
		//assertEquals(res.startsWith("C"), false);
		assertEquals(hold.isReserved(), false);

		
		res = impl.reserveSeats(hold.getSeatHoldId(), "abc@hai.com");
		//assertEquals(res.startsWith("C"), true);
		assertEquals(hold.isReserved(), true);
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 0);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 88);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.RESERVED.getStatus())).size() , 2);
		
	}
	
	@Test
	public void testReserveSeatsAtMezza9() {
		
		init = new TicketServiceInit(10);
		
		impl.setRequiredLevel(SeatLevel.MEZZANINE.getLevel());
		SeatHold hold =impl.findAndHoldSeats(2, "abc@hai.com") ;
		Double amoun = 100d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		
		String res = impl.reserveSeats(hold.getSeatHoldId(), "abcwrong@hai.com");
		//assertEquals(res.startsWith("C"), false);
		assertEquals(hold.isReserved(), false);

		
		res = impl.reserveSeats(hold.getSeatHoldId(), "abc@hai.com");
		//assertEquals(res.startsWith("C"), true);
		assertEquals(hold.isReserved(), true);
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 0);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 88);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.RESERVED.getStatus())).size() , 2);
		
	}
	
	@Test
	public void testReserveAllSeats() {
		
		init = new TicketServiceInit(10);
		
		SeatHold hold =impl.findAndHoldSeats(90, "abc@hai.com") ;
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		
		String res = impl.reserveSeats(hold.getSeatHoldId(), "abcwrong@hai.com");
		//assertEquals(res.startsWith("C"), false);
		assertEquals(hold.isReserved(), false);

		
		res = impl.reserveSeats(hold.getSeatHoldId(), "abc@hai.com");
		//assertEquals(res.startsWith("C"), true);
		assertEquals(hold.isReserved(), true);
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 0);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 0);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.RESERVED.getStatus())).size() , 90);
		
	}
}
