package com.walmart.tickte.test.ticketService;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.walmart.ticket.service.constants.SeatLevel;
import com.walmart.ticket.service.constants.SeatStatusEnum;
import com.walmart.ticket.service.impl.TicketServiceImpl;
import com.walmart.ticket.service.impl.TicketServiceInit;
import com.walmart.ticket.service.model.SeatHold;

public class FindAndHoldSeatsTest {
	
	TicketServiceImpl impl=null;
	TicketServiceInit init=null;
	
	@Before
	public void init(){
		 init = new TicketServiceInit(10);
		 impl = new TicketServiceImpl();
	}

	@Test
	public void testFindAndHoldSeats() {
		init = new TicketServiceInit(10);
		impl.setRequiredLevel(SeatLevel.ORCHESTRA.getLevel());
		SeatHold hold =impl.findAndHoldSeats(30, "abc@hai.com") ;
		Double amoun = 3000d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 30);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 60);
		
		
		
	}
	
	@Test
	public void testFindAndHoldAllSeats() {
		init = new TicketServiceInit(10);
		impl.setRequiredLevel("none");
		SeatHold hold =impl.findAndHoldSeats(90, "abc@hai.com") ;
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 90);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 0);	
		
	}
	
	@Test
	public void testFindAndHoldAllSeatsAtOrchestra() {
		init = new TicketServiceInit(10);
		impl.setRequiredLevel(SeatLevel.ORCHESTRA.getLevel());
		SeatHold hold =impl.findAndHoldSeats(30, "abc@hai.com") ;
		Double amoun = 3000d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 30);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 60);
		impl.setRequiredLevel(SeatLevel.ORCHESTRA.getLevel());
		 assertEquals(impl.numSeatsAvailable(), 0);
		
	}
	
	@Test
	public void testFindAndHoldAllSeatsAtMezza9() {
		init = new TicketServiceInit(10);
		impl.setRequiredLevel(SeatLevel.MEZZANINE.getLevel());
		SeatHold hold =impl.findAndHoldSeats(30, "abc@hai.com") ;
		Double amoun = 1500d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 30);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 60);
		impl.setRequiredLevel(SeatLevel.MEZZANINE.getLevel());
		 assertEquals(impl.numSeatsAvailable(), 0);
		
	}
	
	@Test
	public void testFindAndHoldAllSeatsAtBalcony() {
		init = new TicketServiceInit(10);
		impl.setRequiredLevel(SeatLevel.BALCONY.getLevel());
		SeatHold hold =impl.findAndHoldSeats(30, "abc@hai.com") ;
		Double amoun = 750d;
		assertEquals(hold.getTotalAmount(), amoun);
		assertEquals(hold.isReserved(), false);
		assertEquals(hold.getCustomerEmail(), "abc@hai.com");
		//System.out.println((TicketServiceInit.seats.get(SeatStatusEnum.HOLD)));
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus())).size() , 30);
		assertEquals((TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())).size() , 60);
		impl.setRequiredLevel(SeatLevel.BALCONY.getLevel());
		assertEquals(impl.numSeatsAvailable(), 0);
		
	}

}
