/**
 * 
 */
package com.walmart.ticket.service.util;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * @author Mandar Puranik
 *
 */
public class UIDGenerator {
	
	public static int getConfirmationnumber(){
		SecureRandom secureRandom = null;
		int confirmationNumber = 235412323;
		try {
			secureRandom = SecureRandom.getInstance("SHA1PRNG");
			byte[] bytes = new byte[128];
			secureRandom.nextBytes(bytes);
			confirmationNumber = secureRandom.nextInt(Integer.MAX_VALUE);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		
		return confirmationNumber;
			
	}

}
