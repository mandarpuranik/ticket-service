/**
 * 
 */
package com.walmart.ticket.service.task;

import static com.walmart.ticket.service.impl.TicketServiceInit.seatHoldMap;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimerTask;

import com.walmart.ticket.service.impl.TicketServiceImpl;
import com.walmart.ticket.service.impl.TicketServiceInit;
import com.walmart.ticket.service.model.SeatHold;

/**
 * @author mandar puranik
 *
 */
public class SeatReleaseTask extends TimerTask {
	
	 @Override  
	 public void run() { 
		 
		 findExpiredHeldSeats();
		 
	 }
	 
	 public void findExpiredHeldSeats(){
		 
		 if(null != seatHoldMap && 0 != seatHoldMap.size()){
			 Iterator<Entry<Integer, SeatHold>> it = seatHoldMap.entrySet().iterator();;
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        SeatHold seatHold = (SeatHold) pair.getValue();
			        if(((System.currentTimeMillis()-seatHold.getTimeStamp()) >= TicketServiceInit.holdTime) &&
			        		(!seatHold.isReserved()))
			        {
				        System.out.println(seatHold.getSeatHoldId() + " -->Hold for Longer time by :"
				        		+seatHold.getCustomerEmail()+"After :"
				        		+ ((System.currentTimeMillis()-seatHold.getTimeStamp())));
			        	TicketServiceImpl.releaseHeldTickets(seatHold.getSeatHoldId());
			        	
				        it.remove(); // avoids a ConcurrentModificationException
			        }	
			    }
		 }
		 
		
			}

	 }

   




