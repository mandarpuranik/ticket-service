package com.walmart.ticket.service.vo;

import java.io.Serializable;

public class TicketDTO implements Serializable{

	/**
	 *  Map<String , ArrayList<Seat>>
	 *  
	 *  A 1 2 3 4
	 *  B 1 2 3 4
	 *  
	 *  Seat - int num
	 *  status
	 *  
	 */
	private static final long serialVersionUID = 1L;
	
	private static final int	FIRST_CLASS					=		1;
	private static final int	BUSINESS_CLASS				=		2;
	private static final int	ECONOMY_CLASS				=		3;
	
	public static final int 	AVAILABLE					=		1;
	public static final int 	RESERVED					=		2;
	public static final int 	HOLD						=		3;
	
	private static final String		FIRST_CLASS_STR				=	"First Class";
	private static final String		BUSINESS_CLASS_STR			=	"Business Class";
	private static final String		ECONOMY_CLASS_STR			=	"Economy Class";
	
	
	
	private Integer seatNumber;
	private String customerEmail;
	private Integer priority;
	private Integer status;
	
	public Integer getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(Integer seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getPriorityStr()
	{
		String str = "";
		switch(this.priority)  {
		case  FIRST_CLASS : 
			str = FIRST_CLASS_STR;
			break;
		case BUSINESS_CLASS : 
			str = BUSINESS_CLASS_STR;
			break;
		case ECONOMY_CLASS : 
			str = ECONOMY_CLASS_STR;
			break;
		}
		return str;
	}
	@Override
	public String toString() {
		return "TicketDTO [seatNumber=" + seatNumber
				+ ", customerEmail=" + customerEmail + ", priority=" + priority
				+ ", status=" + status + "]";
	}
}
