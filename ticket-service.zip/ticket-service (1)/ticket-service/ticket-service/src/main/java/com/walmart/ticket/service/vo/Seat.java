/**
 * 
 */
package com.walmart.ticket.service.vo;

import java.io.Serializable;
import java.util.Comparator;

import com.walmart.ticket.service.constants.SeatStatusEnum;

/**
 * @author mandar puranik
 *
 */


public class Seat implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String seatNumber ;//a12
	private SeatStatusEnum status;
	private String level;
	private Double price = 0.0d;
	
	
	

	public Seat(String seatNumber, SeatStatusEnum status , String level, Double price) {
		this.seatNumber = seatNumber;
		this.status = status;
		this.level=level;
		this.price=price;
	}


	/**
	 * @return the seatNumber
	 */
	public String getSeatNumber() {
		return seatNumber;
	}


	/**
	 * @param seatNumber the seatNumber to set
	 */
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}


	/**
	 * @return the status
	 */
	public SeatStatusEnum getStatus() {
		return status;
	}


	/**
	 * @param status the status to set
	 */
	public void setStatus(SeatStatusEnum status) {
		this.status = status;
	}
	
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}


	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}


	/**
	 * @return the price
	 */
	public Double getPrice() {
		return price;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((seatNumber == null) ? 0 : seatNumber.hashCode());
		return result;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seat other = (Seat) obj;
		if (seatNumber == null) {
			if (other.seatNumber != null)
				return false;
		} else if (!seatNumber.equals(other.seatNumber))
			return false;
		return true;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return  seatNumber;
	}


	
}

