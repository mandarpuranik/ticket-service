/**
 * 
 */
package com.walmart.ticket.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.walmart.ticket.service.constants.SeatLevel;
import com.walmart.ticket.service.constants.SeatStatusEnum;
import com.walmart.ticket.service.model.SeatHold;
import com.walmart.ticket.service.vo.Seat;

/**
 * @author mandar puranik
 *
 */
public class TicketServiceInit {
	
	public static Map<String,List<Seat>> seats = new ConcurrentHashMap<String, List<Seat>>();
	public static Map<Integer,SeatHold> seatHoldMap = new ConcurrentHashMap<Integer, SeatHold>();
	public static long holdTime =120000;
	public static long holdTimeMins =2;
	
	public TicketServiceInit(int column)
	{
      	//int column=30;
			
		List<Seat> seatSet= new ArrayList<Seat>();
		for(SeatLevel levels : SeatLevel.values()){
			for( char row : levels.getRows()){
				for(int j = 1; j<=(column);j++){
					seatSet.add(new Seat(String.valueOf(row)+j ,SeatStatusEnum.AVAILABLE, levels.getLevel(),levels.getAmount()));
					
				}
			}
		}	
		seats.put(SeatStatusEnum.AVAILABLE.getStatus(), seatSet);
		seats.put(SeatStatusEnum.HOLD.getStatus(), new ArrayList<Seat>());
		seats.put(SeatStatusEnum.RESERVED.getStatus(), new ArrayList<Seat>());

		
			
	}

}
