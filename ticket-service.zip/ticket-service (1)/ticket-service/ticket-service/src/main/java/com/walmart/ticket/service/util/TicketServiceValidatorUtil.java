/**
 * 
 */
package com.walmart.ticket.service.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author mandar puranik
 *
 */
public class TicketServiceValidatorUtil {
	
	private static final String EMAIL_PATTERN =	"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

	private static Pattern pattern;
	private static Matcher matcher;

	
	public static boolean isEmpty(String string){
		if(null != string && ""!=string){
			return false;
		}
		return true;
	}
	
	public static boolean isValidEmail(String emailId){
		pattern = Pattern.compile(EMAIL_PATTERN);
		matcher = pattern.matcher(emailId);
		return matcher.matches();
				
	}

}
