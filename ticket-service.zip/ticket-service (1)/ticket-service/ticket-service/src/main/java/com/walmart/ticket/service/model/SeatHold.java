package com.walmart.ticket.service.model;

import java.io.Serializable;
import java.util.List;

import com.walmart.ticket.service.vo.Seat;

public class SeatHold implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String customerEmail;
	private List<Seat> seat;
	private Double totalAmount=0.0;
	private int seatHoldId = 0;
	private boolean isReserved;
	private long timeStamp;
	

	public SeatHold(String customerEmail, List<Seat> seat, Double totalAmount) {
		this.customerEmail = customerEmail;
		this.seat = seat;
		this.totalAmount = totalAmount;
		this.timeStamp = System.currentTimeMillis();
	}




	/**
	 * @return the seat
	 */
	public List<Seat> getSeat() {
		return seat;
	}



	/**
	 * @param seat the seat to set
	 */
	public void setSeat(List<Seat> seat) {
		this.seat = seat;
	}



	/**
	 * @return the totalAmount
	 */
	public Double getTotalAmount() {
		return totalAmount;
	}



	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}



	/**
	 * @return the customerEmail
	 */
	public String getCustomerEmail() {
		return customerEmail;
	}



	/**
	 * @param customerEmail the customerEmail to set
	 */
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}



	/**
	 * @return the seatHoldId
	 */
	public int getSeatHoldId() {
		return seatHoldId;
	}




	/**
	 * @param seatHoldId the seatHoldId to set
	 */
	public void setSeatHoldId(int seatHoldId) {
		this.seatHoldId = seatHoldId;
	}





	/**
	 * @return the isReserved
	 */
	public boolean isReserved() {
		return isReserved;
	}




	/**
	 * @param isReserved the isReserved to set
	 */
	public void setReserved(boolean isReserved) {
		this.isReserved = isReserved;
	}




	/**
	 * @return the timeStamp
	 */
	public long getTimeStamp() {
		return timeStamp;
	}
	

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customerEmail == null) ? 0 : customerEmail.hashCode());
		result = prime * result + ((seat == null) ? 0 : seat.hashCode());
		result = prime * result + seatHoldId;
		return result;
	}




	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SeatHold other = (SeatHold) obj;
		if (customerEmail == null) {
			if (other.customerEmail != null)
				return false;
		} else if (!customerEmail.equals(other.customerEmail))
			return false;
		if (seat == null) {
			if (other.seat != null)
				return false;
		} else if (!seat.equals(other.seat))
			return false;
		if (seatHoldId != other.seatHoldId)
			return false;
		return true;
	}
	


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Booking Details : \n"
				+ "* Booking ID : "+  (isReserved?"C"+seatHoldId:seatHoldId )  + "\n* CurrentStatus : " +  (isReserved?"Resrved":"Hold")  + " \n* customerEmail : " + customerEmail + ",\n*seatNumbers : " + seat + ", \n*totalAmount : " + totalAmount;
	}

	

}
