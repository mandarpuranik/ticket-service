package com.walmart.ticket.service.constants;

public enum SeatStatusEnum {
	
	AVAILABLE("AVAILABLE"),HOLD("HOLD"),RESERVED("RESERVED");
	
	private String status;
	
	SeatStatusEnum(String status){
		this.status= status;
	}
	
	public String getStatus(){
		return status;
	}

}
