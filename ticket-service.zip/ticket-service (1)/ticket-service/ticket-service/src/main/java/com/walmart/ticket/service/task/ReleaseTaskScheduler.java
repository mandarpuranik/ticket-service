/**
 * 
 */
package com.walmart.ticket.service.task;

import java.util.Timer;

/**
 * @author Mandar Puranik
 *
 */
public class ReleaseTaskScheduler {
	
	public static void scheduleTask()
	{
		Timer timer = new Timer();
		timer.scheduleAtFixedRate(new SeatReleaseTask(), 1000, 4000);
	}

}
