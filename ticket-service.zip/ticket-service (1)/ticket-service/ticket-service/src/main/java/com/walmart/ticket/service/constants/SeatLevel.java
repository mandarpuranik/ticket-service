package com.walmart.ticket.service.constants;

public enum SeatLevel {
	
	//1 ()
	ORCHESTRA(1, "ORCHESTRA",new char [] {'A','B','C'},100.00),
	MEZZANINE(2,  "MEZZANINE", new char [] {'D','E','F'},50.00),
	BALCONY( 3, "BALCONY",new char [] {'G','H','I'},25.00);
	
	private SeatLevel(int levelNumber, String level, char [] rows,  Double amount) {
		this.level = level;
		this.amount = amount;
		this.rows=rows;
		this.levelNumber=levelNumber;
	}
	
	private String level = null;
	private Double amount = 0.0;
	private  char [] rows;
	private int levelNumber;
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @return the amount
	 */
	public Double getAmount() {
		return amount;
	}
	
	public char[] getRows(){
		return rows;
	}
	/**
	 * @return the levelNumber
	 */
	public int getLevelNumber() {
		return levelNumber;
	}

	
}
