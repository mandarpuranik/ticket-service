/**
 * 
 */
package com.walmart.ticket.service.main;

import static com.walmart.ticket.service.impl.TicketServiceInit.seatHoldMap;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.walmart.ticket.service.constants.SeatLevel;
import com.walmart.ticket.service.impl.TicketServiceImpl;
import com.walmart.ticket.service.impl.TicketServiceInit;
import com.walmart.ticket.service.model.SeatHold;
import com.walmart.ticket.service.task.ReleaseTaskScheduler;
import com.walmart.ticket.service.util.TicketServiceValidatorUtil;

/**
 * @author mandar puranik
 *
 */
public class TicketServiceMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		new TicketServiceInit(30);
		ReleaseTaskScheduler.scheduleTask();
		TicketServiceImpl ticketServiceImpl = new TicketServiceImpl();

		System.out.println("*****  Welcome to the Discovery Theatre INC. ticket service.  *****");

		loop: while (true) {

			System.out.println("");
			System.out.println("");
			System.out.println("Please choose from the choices below.");
			System.out.println("1. Find the number of seats available at Venue.");
			System.out.println("2. Find and hold seats in the theater.");
			System.out.println("3. Reserve seats.");
			System.out.println("4. Exit from the system.");
			System.out.println();
			System.out.println();

			Scanner scanner = new Scanner(System.in);
			int input;
			try {
				input = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Please enter an integer value within the range.\n");
				continue;
			}

			outerSwitch: switch (input) {

			case (1): {
				ticketServiceImpl.setRequiredLevel("none");
				System.out.println("Total number of seats available in Theatre : " + ticketServiceImpl.numSeatsAvailable());
				System.out.println();
				System.out.println("----------------------------------------------");
				System.out.println("Number of seats available in each levels :");
				System.out.println("----------------------------------------------");
				System.out.println(	"| Level  | Price   | Number of seats Available");
				System.out.println("----------------------------------------------");

				for (SeatLevel sl : SeatLevel.values()) {
					ticketServiceImpl.setRequiredLevel(sl.getLevel());

					System.out.println("| " + sl.getLevel() + "  | " + sl.getAmount()
					+ "  | " + ticketServiceImpl.numSeatsAvailable());
					System.out.println("------------------------------------------");
				}
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				break;
			}

			case 2: {
				SeatHold seatHold = null;
				String customerEmail = null;
				System.out.println("Please enter the number of seats you would like to reserve.\n");
				Scanner scanner1 = new Scanner(System.in);
				Integer numSeats;
				String preference;
				Integer levelNumber;
				try {
					numSeats = scanner1.nextInt();
					System.out.println("Do you have Seat Level preference? (y/n)\n");
					System.out.println(scanner1.nextLine());
					preference= scanner1.nextLine();

					boolean invalidOption = true;
					
					int invalidOptionCounter =0;

					invalidPreferenceLoop :while (invalidOption) {



						if (null != preference && "" != preference) {

							if ("y".equalsIgnoreCase(preference)) {
								invalidOption = false;

								System.out.println("Please enter the level number in which you would like to reserve seats \n ");
								boolean invalidlevel = true;
								int invalidlevelCounter =0;
								
								invalidlevel : while (invalidlevel) {

									for (SeatLevel sl : SeatLevel.values()) {
										System.out.println(sl.getLevelNumber() + "|" + sl.getLevel() + "  |  Price : "
												+ sl.getAmount() + "|");

									}

									levelNumber = scanner1.nextInt();
									
									for (SeatLevel sl : SeatLevel.values()) {
										if (sl.getLevelNumber() == levelNumber) {
											ticketServiceImpl.setRequiredLevel(sl.getLevel());
											invalidlevel = false;
											break;
										}

									}
									if (invalidlevel) {
										invalidlevelCounter++;
										if(6 >= invalidlevelCounter){
											System.out.println();
											System.out.println("Multiple invalid attempts!!");
											break invalidPreferenceLoop;
											
										}
										System.out.println();
										System.out.println("Level not found !! Please enter correct level number from below list.\n");
										continue invalidlevel;
									}
								}

							} else if ("n".equalsIgnoreCase(preference)) {
								invalidOption = false;
								ticketServiceImpl.setRequiredLevel("none");
							} else {
								invalidOptionCounter++;
								System.out.println();
								System.out.println("Invalid option selected. Please enter correct Value.(y/n) \n");
								//System.out.println(scanner1.nextLine());
								preference= scanner1.nextLine();
								continue invalidPreferenceLoop;
							}
							System.out.println();
							System.out.println("Please enter email Id to hold tickets: \n");
							System.out.println(scanner1.nextLine());
							
							customerEmail = scanner1.nextLine();
							if(! TicketServiceValidatorUtil.isValidEmail(customerEmail)){
								System.out.println("Re-enter email Id to hold tickets :\n");
								
								//System.out.println(scanner1.nextLine());
								customerEmail = scanner1.nextLine();
								if(!TicketServiceValidatorUtil.isValidEmail(customerEmail)){
									break outerSwitch;
								}
							}
							seatHold = ticketServiceImpl.findAndHoldSeats(numSeats, customerEmail);
							if (null != seatHold) {
								System.out.println();
								System.out.println(seatHold);
								System.out.println("\nSystem will hold tickets for "+ TicketServiceInit.holdTimeMins+ " mins...");
							} else {
								invalidOption = true;
								System.out.println("Do you have Seat Level preference? (y/n)\n");
								//System.out.println(scanner1.nextLine());
								preference= scanner1.nextLine();
								continue invalidPreferenceLoop;
							}

						} else {
							invalidOptionCounter++;
							if(6 >= invalidOptionCounter){
								System.out.println();
								System.out.println("Multiple invalid attempts!!");
								break outerSwitch;
							}
							System.out.println();
							System.out.println("Invalid option selected. Please enter correct Value. (y/n) \n");
							System.out.println(scanner1.nextLine());
							preference= scanner1.nextLine();
							continue invalidPreferenceLoop;
						}

					}

					System.out.println();
					System.out.println("1. Confirm seats now");
					System.out.println("2. Confirm later\n");
					Integer selection;
					try {
						selection = scanner1.nextInt();
					} catch (java.util.InputMismatchException e) {
						System.out.println("Invalid option selected. \n");
						break outerSwitch;
					}
					if (1 == selection) {
						ticketServiceImpl.reserveSeats(seatHold.getSeatHoldId(), (null!=customerEmail)?customerEmail:null);
						System.out.println();
						System.out.println("Congragulations!! Your ticket is booked for show.\n" + seatHold);
					}
				} catch (java.util.InputMismatchException e) {
					System.out.println("Invalid input entered !!! \n");
					break;
				}
				break;
			}

			case (3): {
				Scanner scanner1 = new Scanner(System.in);
				System.out.println("Please enter emailId to confirm tickets \n");
				String customerEmail = scanner1.nextLine();
				if(!TicketServiceValidatorUtil.isValidEmail(customerEmail)){
					System.out.println("Re-enter email Id to confirm tickets :\n");
					
					//System.out.println(scanner1.nextLine());
					customerEmail = scanner1.nextLine();
					if(!TicketServiceValidatorUtil.isValidEmail(customerEmail)){
						System.out.println("Please try again..");
						break outerSwitch;
					}
				}
				System.out.println("Please enter seatHoldId to hold tickets \n");
				Integer seatHoldId;
				try {
					seatHoldId = scanner1.nextInt();
				
				String ConfirmationId = ticketServiceImpl.reserveSeats(seatHoldId, customerEmail);
				if(null != ConfirmationId){
					System.out.println("Congragulations!! Your ticket is booked for show.\n" + seatHoldMap.get(seatHoldId));
				}
				else{
					System.out.println("Invalid ticket hold confirmation number entered !!");
				}
				
				} catch (java.util.InputMismatchException e) {
					System.out.println("Invalid input entered !!!");
					break;
				}

				break;
			}

			case (4): {

				System.exit(0);
			}

			default: {
				System.out.println("Wrong input. Please try again between the given values.");
				break;
			}

			}
		}


	}

}
