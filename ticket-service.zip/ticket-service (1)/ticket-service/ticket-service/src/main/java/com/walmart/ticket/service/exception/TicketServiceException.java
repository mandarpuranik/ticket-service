/**
 * 
 */
package com.walmart.ticket.service.exception;

/**
 * @author mandar puranik
 *
 */
public class TicketServiceException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String message;

	public TicketServiceException(String message) {
		this.message = message;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	
	

}
