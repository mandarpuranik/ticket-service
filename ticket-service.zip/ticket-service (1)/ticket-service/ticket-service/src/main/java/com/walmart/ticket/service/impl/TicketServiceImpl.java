/**
 * 
 */
package com.walmart.ticket.service.impl;

import java.util.ArrayList;
import static com.walmart.ticket.service.impl.TicketServiceInit.seatHoldMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.walmart.ticket.service.TicketService;
import com.walmart.ticket.service.constants.SeatStatusEnum;
import com.walmart.ticket.service.model.SeatHold;
import com.walmart.ticket.service.util.UIDGenerator;
import com.walmart.ticket.service.vo.Seat;
import com.walmart.ticket.service.vo.TicketDTO;

/**
 * @author mandar puranik
 *
 */
public class TicketServiceImpl implements TicketService{
	Map<Integer,TicketDTO> seatMap = new HashMap<Integer, TicketDTO>();
    
	
	private String requiredLevel="none";
	

	public int numSeatsAvailable() {		

		return  getSeatsByLevel(requiredLevel).size();
	}

	public SeatHold findAndHoldSeats(int numSeats, String customerEmail) {
		
		//for requiredLevel
		SeatHold seatHold = null;
		List<Seat> list = new ArrayList<Seat>();
		int totalHoldSeats = 1;
		Double totalPrice = 0.0d;
		
		List<Seat> listByLevel = getSeatsByLevel(requiredLevel);
		if(TicketServiceInit.seats!=null && listByLevel.size()>0)
		{
			if(numSeats <= listByLevel.size())
			{
				for(Seat obj : listByLevel)
				{

					if(totalHoldSeats <=numSeats)
					{
						obj.setStatus(SeatStatusEnum.HOLD);
						TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus()).add(obj);
						totalPrice=obj.getPrice()+totalPrice;						
						list.add(obj);
						totalHoldSeats++;
					}
					else{
						break;
					}
				}
				seatHold= new SeatHold(customerEmail, list, totalPrice);
				seatHold.setSeatHoldId(UIDGenerator.getConfirmationnumber());
				seatHoldMap.put(seatHold.getSeatHoldId(), seatHold);
				updateMap(TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus()), SeatStatusEnum.HOLD.getStatus());
			}else{
				System.out.println("only - "+listByLevel.size() +" are available , please try another level");
			}
		}
		return seatHold;
	}

	public String reserveSeats(int seatHoldId, String customerEmail) {
		
		SeatHold seatHold;
		StringBuffer confirmationId = new StringBuffer("C");

		if (null != String.valueOf(seatHoldId) && null != customerEmail && "" != customerEmail) {

			List<Seat> list = new ArrayList<Seat>();
			seatHold = seatHoldMap.get(seatHoldId);
			if (!seatHold.isReserved() && seatHold.getCustomerEmail().equals(customerEmail)) {

				for (Seat seat : seatHold.getSeat()) {
					seat.setStatus(SeatStatusEnum.RESERVED);
					updateMapbySeatNum(TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus()),
							seat.getSeatNumber());
					list.add(seat);
					TicketServiceInit.seats.get(SeatStatusEnum.RESERVED.getStatus()).add(seat);
				}
				seatHold.setReserved(true);
				return (confirmationId.append(String.valueOf(seatHold.getSeatHoldId()))).toString();
			}
		}
		return null;
		
	}
	
	public static void releaseHeldTickets(int seatHoldId) {

		List<Seat> list = new ArrayList<Seat>();
		SeatHold seatHold = seatHoldMap.get(seatHoldId);

			for(Seat seat : seatHold.getSeat()){
				seat.setStatus(SeatStatusEnum.AVAILABLE);
				updateMapbySeatNum(TicketServiceInit.seats.get(SeatStatusEnum.HOLD.getStatus()), 
						seat.getSeatNumber());
				list.add(seat);
				TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus()).add(seat);
			}

		seatHoldMap.remove(seatHoldId);
	}
	
	private void updateMap(List<Seat> seats, String seatStatus)
	{
		Iterator<Seat> it = seats.iterator();
		while (it.hasNext()) {
			Seat seat = it.next();
			if (seat.getStatus().getStatus().equals(seatStatus)) {
				it.remove();
				
			}
		}


	}

	private static void updateMapbySeatNum(List<Seat> seats, String seatNum)
	{
		Iterator<Seat> it = seats.iterator();
		while (it.hasNext()) {
			Seat seat = it.next();
			if (seat.getSeatNumber().equals(seatNum)) {
				it.remove();
				
			}
		}

	}

	public List<Seat> getSeatsByLevel(String level)
	{
		List<Seat> list= new ArrayList<Seat>();
		if(level.equals("none")){
			return TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus());
		}else{
			for(Seat seat : TicketServiceInit.seats.get(SeatStatusEnum.AVAILABLE.getStatus())){
				if(seat.getLevel().equals(level)){
					list.add(seat);
				}
			}
			return list;
		}
		
	}



	/**
	 * @return the requiredLevel
	 */
	public String getRequiredLevel() {
		return requiredLevel;
	}



	/**
	 * @param requiredLevel the requiredLevel to set
	 */
	public void setRequiredLevel(String requiredLevel) {
		this.requiredLevel = requiredLevel;
	}
}
